import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/SEA6ULL/Wizard/master/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://raw.githubusercontent.com/SEA6ULL/Wizard/master/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']

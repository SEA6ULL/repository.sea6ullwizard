# plugin.program.sea6ullwiz
SEA6ULL Wizard is a Kodi maintenance wizard, including cleaning, viewing logs, persisting user data, and even full backup/restore features.

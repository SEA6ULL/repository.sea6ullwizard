# plugin.program.sea6ullwizard
SEA6ULL Wizard is a Kodi maintenance wizard, including installing preconfigured builds, cleaning, viewing logs, persisting user data, speed testing, and even full backup/restore features.
